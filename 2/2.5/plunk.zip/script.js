// Code goes here

var result = 2 + 2;

alert(result);