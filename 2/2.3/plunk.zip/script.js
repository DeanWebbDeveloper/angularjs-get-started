// Code goes here

document.write("Hello, angular!")