// Code goes here

var app = angular.module("myApp", []);

app.controller("MainController", function($scope) {
  $scope.message = "Hello, Angular!";
});